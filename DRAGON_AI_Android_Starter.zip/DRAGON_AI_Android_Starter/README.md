# DRAGON AI - Android starter

Protótipo inicial de um assistente Android nativo (Kotlin), pensado para Android 15.

## O que já existe
- Estrutura Android Studio.
- Tela inicial DRAGON.
- Verificação de disponibilidade biométrica do Android.
- Tela de teste com BiometricPrompt.
- Declaração de um serviço de acessibilidade com descrição transparente.

## Importante: ainda não é um bloqueador completo
O serviço de acessibilidade está propositalmente sem automações. A próxima etapa será implementar:
1. Seletor de aplicativos que o usuário quer proteger.
2. Detecção apenas do pacote do aplicativo aberto.
3. Solicitação de biometria para liberar o app protegido.
4. Aviso local de tentativa de acesso não autorizado.

O Android não permite que um app comum substitua livremente o bloqueio do sistema. O bloqueio será uma camada adicional para aplicativos escolhidos. A biometria é processada pelo Android; o DRAGON não recebe nem armazena imagem facial.

## Como abrir
1. Instale o Android Studio em um computador.
2. Abra a pasta `DRAGON_AI_Android_Starter`.
3. Aguarde a sincronização do Gradle.
4. Conecte seu Android por USB com Depuração USB ativada e execute o app.

## Privacidade
A permissão de Acessibilidade é poderosa e sensível. Ative-a somente depois de revisar o comportamento do app. Este protótipo não lê notificações, mensagens, senhas ou conteúdo de tela e não envia dados para servidores.
