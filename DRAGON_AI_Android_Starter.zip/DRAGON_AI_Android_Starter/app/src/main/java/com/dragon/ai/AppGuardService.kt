package com.dragon.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Protótipo: monitora somente mudanças de aplicativo (nome do pacote).
 * Não captura texto, teclas, senhas ou conteúdo da tela.
 * A lista de apps protegidos e o fluxo de bloqueio serão implementados na próxima etapa.
 */
class AppGuardService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intencionalmente sem ações automáticas nesta primeira versão.
        // Próxima etapa: comparar event.packageName com a lista de apps
        // que o próprio usuário selecionou e solicitar autenticação.
    }
    override fun onInterrupt() = Unit
}
