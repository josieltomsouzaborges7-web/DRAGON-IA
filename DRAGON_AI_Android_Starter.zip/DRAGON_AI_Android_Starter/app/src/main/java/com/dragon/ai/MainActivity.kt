package com.dragon.ai

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(android.graphics.Color.rgb(9, 13, 24))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, pad / 2, 0, pad / 2)
        }
        layout.addView(label("🐉 DRAGON", 30f))
        layout.addView(label("Seu assistente pessoal está despertando.", 17f))
        layout.addView(label("VERSÃO 0.1 • PROTÓTIPO"))
        val bio = BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK
        )
        layout.addView(label(if (bio == BiometricManager.BIOMETRIC_SUCCESS)
            "Biometria: disponível no aparelho"
        else "Biometria: configure um bloqueio de tela e biometria nas Configurações do Android"))
        layout.addView(label(
            "DRAGON GUARD protege aplicativos escolhidos. Para ativar o serviço, abra Acessibilidade e habilite DRAGON Guard. " +
            "A permissão é sensível: use somente no seu aparelho e revise o que está autorizado."
        ))
        layout.addView(Button(this).apply {
            text = "Ativar DRAGON GUARD"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Testar reconhecimento biométrico"
            setOnClickListener { startActivity(Intent(this@MainActivity, LockActivity::class.java)) }
        })
        layout.addView(label(
            "Próxima etapa: tela para escolher apps instalados, regras de bloqueio, alertas e conversa com IA."
        ))
        setContentView(layout)
    }
}
